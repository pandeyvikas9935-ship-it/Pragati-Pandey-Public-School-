# Pragati Pandey Public School — Free Starter Website

यह पहला static prototype है। इसे GitHub Pages जैसी free hosting पर रखा जा सकता है।

अभी इसमें:
- Hindi / English switch
- Home page
- Student/Teacher login buttons (demo)
- Result/Class Work/Online Test sections का प्रारंभिक design

अगले चरण में Firebase जोड़कर वास्तविक login, result, class work और online test बनाया जाएगा।
