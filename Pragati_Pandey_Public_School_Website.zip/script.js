let lang="hi";
function toggleLang(){
  lang=lang==="hi"?"en":"hi";
  document.getElementById("langBtn").textContent=lang==="hi"?"English":"हिंदी";
  document.querySelectorAll("[data-hi]").forEach(el=>el.textContent=el.getAttribute("data-"+lang));
}
